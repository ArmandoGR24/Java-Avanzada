package com.codigomaestro.actividad11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad11ApplicationTests {

    @Test
    void contextLoads() {
    }

}
